//
//  SedraCheck.h
//  SedraCheck
//
//  Created by Zaid Abbas BTIT on 14/11/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for SedraCheck.
FOUNDATION_EXPORT double SedraCheckVersionNumber;

//! Project version string for SedraCheck.
FOUNDATION_EXPORT const unsigned char SedraCheckVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SedraCheck/PublicHeader.h>

#import <SedraCheck/SedraCheck.h>
@import MLKit;
